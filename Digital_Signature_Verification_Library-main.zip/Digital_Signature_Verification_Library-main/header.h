#pragma once
#ifndef SIGNATURELIB_H
#define SIGNATURELIB_H
#include <iostream>
#include <string>
using namespace std;
class DigitalSignature {
private:
    string keyName;
    int hashCode;
    bool isActive;
public:
    // Overloaded Functions (Constructors).
    // 1. Default
    DigitalSignature() {
        keyName = "Guest";
        hashCode = 0;
        isActive = false;
    }
    // 2. Parameterized
    DigitalSignature(string name, int code) {
        keyName = name;
        hashCode = code;
        isActive = true;
    }

    // 3. Alternate (Manual Status)
    DigitalSignature(string name, int code, bool status) {
        keyName = name;
        hashCode = code;
        isActive = status;
    }

    // Overloaded Operators.
    DigitalSignature operator+(const DigitalSignature& other) {
        return DigitalSignature("Combined_Key", this->hashCode + other.hashCode, true);
    }
    DigitalSignature operator-(int value) {
        return DigitalSignature(this->keyName, this->hashCode - value, this->isActive);
    }
    bool operator==(const DigitalSignature& other) {
        return (this->hashCode == other.hashCode);
    }
    friend ostream& operator<<(ostream& out, const DigitalSignature& s) {
        out << "[Key ID: " << s.keyName << " | Hash: " << s.hashCode
            << " | Active: " << (s.isActive ? "Yes" : "No") << "]";
        return out;
    }
};

#endif
