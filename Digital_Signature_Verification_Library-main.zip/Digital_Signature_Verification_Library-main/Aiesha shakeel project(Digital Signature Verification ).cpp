#include <iostream>
#include <string>
#include "SignatureLib.h"

using namespace std;

int main() {
    string name1, name2;
    int hash1, hash2;

    cout << "=== Digital Signature Verification System ===" << endl;

    // Getting input for first signature
    cout << "Enter Name for Signature 1: ";
    getline(cin, name1);
    cout << "Enter Hash Code (Integer): ";
    cin >> hash1;

    // Getting input for second signature
    cin.ignore(); // Clears buffer for getline
    cout << "\nEnter Name for Signature 2: ";
    getline(cin, name2);
    cout << "Enter Hash Code (Integer): ";
    cin >> hash2;

    // Creating objects using Parameterized Constructor
    DigitalSignature sig1(name1, hash1);
    DigitalSignature sig2(name2, hash2);
    DigitalSignature sig3; // Uses Default Constructor

    cout << "\n--- Current Database ---" << endl;
    cout << "Signature 1: " << sig1 << endl;
    cout << "Signature 2: " << sig2 << endl;
    cout << "Default Sig: " << sig3 << endl;

    // Using Operator Overloading (+)
    DigitalSignature combined = sig1 + sig2;
    cout << "\n--- Multi-Sig Merged Result ---" << endl;
    cout << combined << endl;

    // Using Operator Overloading (-)
    int reduction;
    cout << "\nEnter value to reduce Signature 1 hash: ";
    cin >> reduction;
    DigitalSignature reduced = sig1 - reduction;
    cout << "Updated Sig 1: " << reduced << endl;

    // Using Operator Overloading (==)
    cout << "\n--- Verification Result ---" << endl;
    if (sig1 == sig2) {
        cout << "SUCCESS: Signatures match! Access Granted." << endl;
    }
    else {
        cout << "FAILURE: Hash mismatch! Access Denied." << endl;
    }

    cout << "\nPress Enter to exit...";
    cin.ignore();
    cin.get();
    return 0;
}
