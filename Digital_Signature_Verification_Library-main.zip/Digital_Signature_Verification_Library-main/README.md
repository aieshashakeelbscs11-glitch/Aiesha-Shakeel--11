Project Overview
The Digital Signature Verification System is designed to manage and compare digital identities using hash codes. It provides a secure logic-based framework to verify if two signatures are identical, merge multiple signatures, or adjust signature values dynamically.

Core Functionalities
Signature Registration: Allows users to input a name and an associated integer hash code.
Verification Logic: Utilizes comparison operators to determine if two digital signatures match, providing "Access Granted" or "Access Denied" results.
Multi-Signature Merging: Implements a mechanism to combine two signatures into a single "Multi-Sig" result using addition logic.
Technical Features (OOP Principles)
Constructors: Uses both Default and Parameterized Constructors to initialize signature objects with user-defined or system-default data.

Operator Overloading:
==: Re-defined to compare the hash integrity between two objects.
+: Overloaded to merge signature data into a combined object.
-: Overloaded to reduce or update a specific signature’s hash value.
<<: Overloaded (via cout) to display signature details in a clean, readable format.
Buffer Management: Includes input cleaning (cin.ignore) to ensure smooth transitions between string and integer data entry.

Developer: Aiesha Shakeel
Department: Computer Science, Fazaia Bilquis College of Education for Women


